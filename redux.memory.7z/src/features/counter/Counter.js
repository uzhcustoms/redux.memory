import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {  addElem,  selectCells, } from './counterSlice';


export function Counter() {
  const cells = useSelector(selectCells);
  console.log(cells);
  
  const dispatch = useDispatch();
  const handleClick = (e) => {
    dispatch(addElem(e.target.id));
  }

  return (
    <>
    <div className="memory" >
      
    </div>
   
    </>
   );
}