import { createSlice } from '@reduxjs/toolkit';
// Array(N).fill(null).map(() => Array(N))
// Array.from(Array(size), () => new Array(size))
const size = 4;
const initialState = {couter: 0, cells: Array.from(Array(size), () => new Array(size))};

let val = 1;
for(let i = 0; i< initialState.cells.length; i++) {
  
  for (let j = 0; j< initialState.cells[i].length; j++) {
    if (val == size * (size / 2) + 1) {
      val = 1;
    }
    initialState.cells[i][j] = val;
    val++;
  }
}
for(let j = 0; j < 20; j++) {
  for(let i = 0; i< initialState.cells.length; i++) {
    initialState.cells[i].sort(() => Math.random() - 0.5);
    initialState.cells.sort(() => Math.random() - 0.5);
  }
}

console.log(initialState.cells);
export const counterSlice = createSlice({
  name: 'counter',
  initialState,
  reducers: {
    addElem: (state, action) => {
          
    },
  },
});

export const { addElem } = counterSlice.actions;

export const selectCells = (state) => state.counter.cells;

export default counterSlice.reducer;

 
